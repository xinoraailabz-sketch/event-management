import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      // Allow ngrok, Cloudflare tunnels, and mobile local testing
      allowedHosts: true,
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
      // Proxy Maileroo API to bypass browser CORS restrictions.
      // The browser calls /api/maileroo/* and Vite forwards it to smtp.maileroo.com server-side.
      proxy: {
        '/api/maileroo': {
          target: 'https://smtp.maileroo.com/api/v2',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api\/maileroo/, ''),
          secure: true,
        },
      },
    },
  };
});
